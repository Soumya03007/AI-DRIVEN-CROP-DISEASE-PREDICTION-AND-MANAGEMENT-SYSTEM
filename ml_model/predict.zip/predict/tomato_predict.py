import cv2 as cv
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.models import load_model

# Load the saved model for prediction
model = load_model(r'C:\pratik 1\model\crop_disease_model_tomato.keras')

# Define the class names (ensure they match the order in which they were trained)
class_names = [
    #'Apple_Scab', 'Apple_BlackRot', 'Apple_Cedar_apple_rust', 'Apple_Healthy', 
               #'Blueberry_Healthy',
               #'Cherry_(including_sour)Powdery_mildew', 'Cherry(including_sour)_healthy',  
               #'Corn_(maize)Cercospora_leaf_spot Gray_leaf_spot', 'Corn(maize)Common_rust', 'Corn_(maize)Northern_Leaf_Blight', 'Corn_(maize)_healthy', 
              # 'Grape_Black_rot', 'Grape_Esca(Black_Measels)', 'Grapeleaf_blight(Isariopsis_leaf_spot)',  'Grape_healthy',
               #'Orange_huanglongbing(Citrus_greening)', 
               #'Peach_Bacteral_spot', 'Peach_Healthy', 
               #'Pepper_BellBacterial_spot', 'Pepper_Bell_Healthy', 
               #'Potato_Early_blight', 'PotatoHealthy', 'Potato_Late_blight', 
               #'Raspberry_Healthy', 
               #'SoyabeanHealthy', 
               #'Squash_Powdery_mildew', 
               #'Strawberry_Healthy', 'StrawberryLeaf_scorch', 
               
               'Tomato__Bacterial_spot', 
               'Tomato_Early_blight', 'Tomato_healthy', 'Tomato_Late_blight', 
               'Tomato_Leaf_Mold', 'Tomato_Septoria_leaf_spot', 
               'Tomato_Spider_mites Two-spotted_spider_mite', 'Tomato_Target_Spot', 
               'Tomato__Tomato_mosaic_virus', 'Tomato_Tomato_Yellow_Leaf_Curl_Virus'
               
]

# Define the disease information (Preventive Measures and Medications)
disease_info = {
    'Tomato__Bacterial_spot': {
        'Preventive Measures': "Use disease-free seeds and resistant varieties. Avoid overhead irrigation and practice crop rotation.",
        'Medications': "Apply copper-based fungicides to control the spread of the disease."
    },
    'Tomato__Early_blight': {
        'Preventive Measures': "Practice crop rotation and use resistant varieties. Remove infected plant debris.",
        'Medications': "Fungicides like mancozeb or chlorothalonil can help manage symptoms."
    },
    'Tomato__Tomato_mosaic_virus': {
        'Preventive Measures': "Use virus-free seeds and practice good sanitation. Remove and destroy infected plants.",
        'Medications': "No chemical treatment available; focus on prevention and control of aphid populations."
    },
    'Tomato__healthy': {
        'Preventive Measures': "Maintain good field management practices, proper irrigation, and pest control.",
        'Medications': "No action needed."
    },
}

# Load and preprocess the test image
img_path = r'C:\pratik 1\train\tomato\Tomato__Tomato_mosaic_virus\1b9dc07a-40ab-45bc-a873-1ad4212e35a3__PSU_CG 2289.JPG'  # Update with the path to the tomato image
img = cv.imread(img_path)
img = cv.cvtColor(img, cv.COLOR_BGR2RGB)

# Resize the image to match the input size of the model (180x180)
img_resized = cv.resize(img, (180, 180))

# Normalize the image
img_array = np.array([img_resized]) / 255.0  # Scale pixel values to [0, 1]

# Display the image
plt.imshow(img_resized)
plt.axis('off')  # Hide the axes for a better display
plt.show()

# Make the prediction
prediction = model.predict(img_array)
print(f"Model Prediction Output: {prediction}")  # Debugging: Print the prediction output

# Check if the prediction output size matches the number of classes
if len(prediction[0]) != len(class_names):
    print(f"Warning: The number of predicted classes ({len(prediction[0])}) does not match the number of defined class names ({len(class_names)}).")
else:
    index = np.argmax(prediction)
    print(f"Predicted Index: {index}")  # Debugging: Print the predicted index

    # Get the predicted label
    predicted_label = class_names[index]
    print(f'Prediction: {predicted_label}')

    # Print the keys of the disease_info dictionary
    print("Keys in disease_info:", list(disease_info.keys()))

    # Fetch and display preventive measures and medications
    if predicted_label in disease_info:
        preventive_measures = disease_info[predicted_label]['Preventive Measures']
        medications = disease_info[predicted_label]['Medications']

        print(f"Preventive Measures: {preventive_measures}")
        print(f"Medications: {medications}")
    else:
        print(f"No information available for this disease. Predicted label: {predicted_label}")